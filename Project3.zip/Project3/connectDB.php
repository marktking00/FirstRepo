<?php
      $dbConn = mysqli_connect("localhost", "root", "", "CPT238Project3");
      if (!$dbConn)
      {
       	die('Could not connect: '. $dbConn->connect_error);
      }
      //jackieJewelry is the name of the db
      $dbObj = mysqli_select_db($dbConn, "CPT238Project3");
?>