<?php
include("connectDB.php");
// variables from connectDB.php: $dbConn - connection object
if(isset($_POST['btnSubmit']))
	{
         $sqlStatement="INSERT INTO Users (username, mothermaidenname, firstname, lastname, passwd) VALUES
        ('$_POST[txtUserName]', '$_POST[txtMMN]', '$_POST[txtFirstName]', '$_POST[txtLastName]', '$_POST[txtPassword]')";
//        echo $sqlStatement;
         if (!mysqli_query($dbConn, $sqlStatement))
            {
            die('Error: '. $dbConn->connect_error);
            }
        echo "<h2>RECORD ADDED</h2>";
        include("closeDB.php");
       }
       ?>