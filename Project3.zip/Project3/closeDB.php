<?php
      mysqli_close($dbConn);
?>