<?php include ('insert.php'); ?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New User</title>
    <style>
            #container{margin:0 auto;width:90%;}
            h1{text-align:center;}
            h2{text-align:center;}
            h3{text-align:center;}
            p{text-align:center;}
            fieldset{margin:20px auto;width:50%;background-color:#eee;}
            legend{font-weight:bold;}
            input[type=text]:focus{background-color:aliceblue;}
        </style>
</head>
<body>
        <form action = "<?php echo $_SERVER['PHP_SELF'];?>" method = "post">
        <div id="container">
                <h1>CPT238 Project 3: New User Screen</h1>
        
                <fieldset>
                    <h3>User Name</h3>
                    <h3><input type="text" name="txtUserName" id="txtUserName" ></h3>
                    <h3>Password</h3>
                    <h3><input type="text" name="txtPassword" id="txtPassword" ></h3>
                    <h3>Confirm Password</h3>
                    <h3><input type="text" name="txtConfirmPassword" id="txtConfirmPassword" ></h3>
                    <h3>First Name</h3>
                    <h3><input type="text" name="txtFirstName" id="txtFirstName" ></h3>
                    <h3>Last Name</h3>
                    <h3><input type="text" name="txtLastName" id="txtLastName" ></h3>
                    <h3>Mother's Maiden Name</h3>
                    <h3><input type="text" name="txtMMN" id="txtMMN" ></h3>
                    <h3><input type="submit" id="btnSubmit" value="Submit" name="btnSubmit"></button> </h3>

                 </fieldset>
    
</body>
</html>